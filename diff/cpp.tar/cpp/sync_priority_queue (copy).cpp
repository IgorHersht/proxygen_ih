
#include <iostream>
#include <boost/thread/concurrent_queues/sync_priority_queue.hpp>


//boost::concurrent::sync_priority_queue<int> int_pq;
struct MyCmp{
	bool operator ()(int la, int ra ){
		return (ra < la);
	}
};
boost::concurrent::sync_priority_queue<int, boost::csbl::vector<int>, MyCmp > int_pq;
int main() {
	int_pq.push(5);int_pq.push(5);int_pq.push(5);
	int_pq.push(1);int_pq.push(1);
	int_pq.push(7);int_pq.push(7);
	///
	int r = int_pq.pull();
	r = int_pq.pull();
	r = int_pq.pull();
	r = int_pq.pull();
	r = int_pq.pull();
	r = int_pq.pull();
	r = int_pq.pull();
	r = int_pq.pull();
	r = int_pq.pull();


	return 0;
}

