
#include <boost/optional/optional.hpp>
#include <iostream>
#include <tuple>

template <class ...Args>
using tuple_view =   std::tuple<Args ... >;




int main()
{


   return 0;
}

