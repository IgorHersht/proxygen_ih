#include <thread>
#include <stack>
#include <mutex>
#include <memory>
#include <atomic>
#include <vector>
#include <deque>
#include <list>
#include <set>
#include <map>
#include <string>
#include <algorithm>
#include <iterator>
#include <functional>
#include <numeric>
#include <iostream>
#include <vector>
#include <list>
#include <deque>
#include <algorithm>
#include <typeinfo>
#include <algorithm>
#include <iterator>
#include <memory>
#include <fstream>
#include <vector>

#include <boost/noncopyable.hpp>

template<typename Derived>
struct singleton : private boost::noncopyable {
    static Derived& instance() { 
        static Derived the_inst; 
        return the_inst; 
      }    
protected:
      ~singleton() {}
      singleton()  {}

};

struct  XX : public singleton<XX>{

 
};
 XX x1;// Not good


struct  YY_singleton : private boost::noncopyable{
    
  static YY_singleton& instance(){
    std::call_once(m__init_flag, init);
    return *m_instance;
  }
private:
  static void init(){
    m_instance = std::shared_ptr<YY_singleton>(new YY_singleton);
  }
   YY_singleton(){}
   static std::once_flag                            m__init_flag;
   static std::shared_ptr<YY_singleton>             m_instance;
};

   std::once_flag                           YY_singleton::m__init_flag;
   std::shared_ptr<YY_singleton>            YY_singleton::m_instance;



 

int main()
{

 XX & x1 = XX::instance();
	return 0;
}
