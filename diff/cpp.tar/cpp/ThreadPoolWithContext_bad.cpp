#include <boost/assert.hpp>
#include <map>
#include <string>
#include <memory>
#include <iostream>
#include <thread>
#include <mutex>
#include <wangle/concurrent/CPUThreadPoolExecutor.h>
#include <boost/thread/executors/basic_thread_pool.hpp>
#include <boost/thread/future.hpp>


struct ThreadContext{

};



static std::vector<std::thread::id> threadIds;

template <typename TCT> struct ThreadPoolWithContext{
typedef std::map<std::thread::id, std::unique_ptr<TCT> > MapT;

template <typename... Args >  static std::unique_ptr<ThreadPoolWithContext> make(Args&&... args){
	std::map<std::thread::id, std::unique_ptr<TCT> > contexts;
	[&contexts](boost::basic_thread_pool& pool){
		contexts.insert( std::pair<std::thread::id, std::unique_ptr<TCT> > (std::this_thread::get_id(), std::unique_ptr<TCT>()) );
	};
	return std::make_unique<ThreadPoolWithContext>(std::move(contexts), std::forward<Args>(args)...);
}
/*
template <typename... Args > ThreadPoolWithContext(Args&&... args ): m_thread_pool(4, at_th_entry ){
	for(auto &id: threadIds){
		 std::unique_ptr<TCT> ptr = std::make_unique<TCT>( std::forward<Args>(args)...);
		m_contexts.insert(std::pair<std::thread::id, std::unique_ptr<TCT> >(id, std::move(ptr) ) );
	}

};
*/
template <typename... Args > ThreadPoolWithContext( std::map<std::thread::id, std::unique_ptr<TCT> > &&contexts, Args&&... args ):
		m_contexts(std::move(contexts)), m_thread_pool(4, at_th_entry ){
	for(auto &el: m_contexts){
		 std::unique_ptr<TCT> ptr = std::make_unique<TCT>( std::forward<Args>(args)...);
		el.second.swap(ptr);
	}
};
private:
/*
static void at_th_entry(boost::basic_thread_pool& pool){
	threadIds.push_back(std::this_thread::get_id());
}
*/
private:
	std::map<std::thread::id, std::unique_ptr<TCT> >	m_contexts;
	boost::basic_thread_pool							m_thread_pool;


};


int main(int argc, char* argv[])
{
	//ThreadPoolWithContext<ThreadContext> context;
	std::unique_ptr<ThreadPoolWithContext<ThreadContext> > cp = ThreadPoolWithContext<ThreadContext>::make();


	return 0;
}

