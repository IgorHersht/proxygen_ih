#include <iostream>
#include <vector>
#include <deque>
#include <list>
#include <set>
#include <map>
#include <string>
#include <boost/thread/thread.hpp>
#include <boost/thread/once.hpp>
#include <boost/shared_ptr.hpp>
#include <boost/weak_ptr.hpp>
#include <iostream>
#include <iostream>
#include <vector>
#include <queue>
#include <list>
#include <set>
#include <map>
#include <string>
#include <algorithm>
#include <iterator>
#include <functional>
#include <numeric>
#include <iostream>
#include <vector>
#include <list>
#include <deque>
#include <algorithm>
#include <iostream>
#include <typeinfo>
#include <algorithm>
#include <iterator>
#include <memory>
#include <string>
//
//  Distributed under the Boost Software License, Version 1.0. (See accompanying
//  file LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)
#include <thread>
template <typename ElementT, int SIZE>
class Buffer : private boost::noncopyable
{
   typedef boost::mutex MutexT;
   typedef boost::mutex::scoped_lock LockT;
   typedef boost::condition_variable ConditionT;
public:
    enum {MAX_SIZE = SIZE};
   // Buffer():m_contaner((int)MAX_SIZE, ElementT() ){}
    void push(ElementT el)
    {
        LockT lock(m_mutex);
        while(m_contaner.size() == MAX_SIZE ){
             m_buffer_not_full.wait(lock);
        }
        m_contaner.push(el);
        m_buffer_not_empty.notify_one();
    }

     ElementT pop()
    {
        LockT lock(m_mutex);
        while(m_contaner.empty()){
             m_buffer_not_empty.wait(lock);
        }
        ElementT el = m_contaner.front();
        m_contaner.pop();
        m_buffer_not_full.notify_one();
        return el;
    }

private:
    std::queue<ElementT>    m_contaner;
    ConditionT              m_buffer_not_full;
    ConditionT              m_buffer_not_empty;
    MutexT                  m_mutex;
    MutexT                  m_iomutex;
};

typedef Buffer<int, 10> Int10BufferT;

boost::mutex io_mutex;
void sender(  Int10BufferT &buf, int num) {

   for(int c = 0; c < num; ++c){
      buf.push(c) ;
      boost::mutex::scoped_lock io_lock(io_mutex);
      std::cout << "push: " << c << std::endl;
   }

}

void receiver( Int10BufferT & buf, int num) {
    for(int c = 0; c < num; ++c){
      int out = buf.pop() ;
      boost::mutex::scoped_lock io_lock(io_mutex);
      std::cout << "pop: " <<out << std::endl;
   }

}


int main(int, char*[])
{
   Int10BufferT buf;
    boost::thread thrd1(boost::bind(sender, boost::ref(buf), 110 ) );
    boost::thread thrd2(boost::bind(receiver,  boost::ref(buf), 110 ));
    thrd1.join();
    thrd2.join();


    return 0;
}
