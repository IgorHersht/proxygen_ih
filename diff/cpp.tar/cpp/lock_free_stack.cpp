#include <exception>
#include <stack>
#include <mutex>
#include <memory>
#include <atomic>

 template<typename T> class lock_free_stac
{
   struct node{
     node(T data):m_data(data),m_next(nullptr){}

     T m_data;
     node* m_next;
   };

   std::atomic< node* > m_head;
public:
  void push(const T& data){
    node* new_node = new node(data);
    new_node->next = m_head.load();
     //m_head.store(new_node);
    while(!m_head.compare_exchange_weak(new_node->next,new_node));
  }
  void pop(T& data){
    node* old_head = m_head.load();
    data = old_head->data;
    //m_head.store(old_head->next);
    while(!m_head.compare_exchange_weak(old_head->next, old_head));

  }


};

int main(int argc, char* argv[]){


  return 0;
}

