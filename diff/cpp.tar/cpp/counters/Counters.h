/*
 * Counters.h
 *
 *  Created on: Jun 12, 2017
 *      Author: ihersht
 */

#pragma once
#include <type_traits>
#include <tuple>
#include <unordered_map>
#include <memory>
#include <boost/circular_buffer.hpp>


namespace cpp_tools{

typedef unsigned int CounterId;
template <typename T> struct Counter{

	Counter(T value):m_value(value){
	}
	operator T() const {return m_value ;}

private:
	T m_value;
};

template <typename T> using CounterWithHisrory = boost::circular_buffer< Counter <T> > ;
template <typename T> using CounterWithHisroryPtr = std::unique_ptr<CounterWithHisrory<T> >;
template <typename T> using Counters = std::unordered_map<CounterId, CounterWithHisroryPtr<T> >;


template< typename... Ts > class CounterContainer{
	typedef std::tuple< Counters<Ts> ... > CountersTuple;
public:
	explicit CounterContainer(size_t size):m_size(size){

	}
	template< class T> CounterWithHisrory<T>* get(CounterId id) {
		Counters<T> & map = std::get< Counters<T> >(m_counters);
		auto iter = map.find(id);
		if(iter == map.end() ){
			return nullptr;
		}
		return iter->second.get();
	}
	constexpr static std::size_t size(){
		return  std::tuple_size<CountersTuple>::value;
	 }
	template< class T> void insert(CounterId id, T&& value) {
		auto * cswh = get<T>(id);
		if(!cswh){
			Counters<T> & map = std::get< Counters<T> >(m_counters);
			auto cswh_u = std::make_unique<CounterWithHisrory<T>>(m_size);
			auto value = std::make_pair(id, std::move(cswh_u));
			auto out = map.insert(std::move(value));
			if( (out.second) ){
				cswh = (out.first)->second.get();
			}
		}
		if(!cswh){
			//codding error;
			return;
		}

		cswh->push_back(value);

	}
private:
	size_t m_size;
	CountersTuple m_counters;
};

}
/*
/// test
#include <iostream>

  int main(int argc, char* argv[]) {

	  cpp_tools::CounterContainer<int, double> allCnts(2);
	  allCnts.insert(2, 1);
	  allCnts.insert(5, 10);
	  allCnts.insert(2, 2);
	  allCnts.insert(5, 11);
	  allCnts.insert(2, 3);
	  allCnts.insert(5, 12);


	  allCnts.insert(3, 1.1);
	  allCnts.insert(6, 10.1);
	  allCnts.insert(3, 2.1);
	  allCnts.insert(6, 11.1);
	  allCnts.insert(3, 3.1);
	  allCnts.insert(6, 12.1);

	  auto * mi2 = allCnts.get<int>(2);
	  if(mi2){
		  for(auto &e: *mi2){
			  std::cout << e << std::endl;
		  }// 2 3
	  }
	  auto * mi5 = allCnts.get<int>(5);
	  if(mi5){
		  for(auto &e: *mi5){
			  std::cout << e << std::endl;
		  }// 11 12
	  }

	  auto * md6 = allCnts.get<double>(6);
	  if(md6){
		  for(auto &e: *md6){
			  std::cout << e << std::endl;
		  }// 11.1 12.1
	  }


  return 0;
}
*/
