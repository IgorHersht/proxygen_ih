
#include <future>
#include <thread>
#include <mutex>
#include <condition_variable>
#include <chrono>
#include <random>
#include <iostream>
#include <exception>
#include<iostream>
#include<vector>
#include<map>
#include<set>
#include<list>
#include<vector>
#include<queue>
#include<algorithm>
using namespace std;

struct S{
    void cp_if(std::vector<int> &from){
      //copy_if(begin(from), end(from))
    }

   int m_div = 2 ;
   vector<int> m_data = vector<int>(10,0);// init 10 elements with 0
   char data[2] {'a','b' };
};


int main(int argc, char* argv[])
{
    S s;
int i =1;

 return 0;
}
 
