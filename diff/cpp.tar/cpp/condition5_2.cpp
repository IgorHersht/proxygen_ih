#include <future>
#include <thread>
#include <mutex>
#include <condition_variable>
#include <chrono>
#include <random>
#include <iostream>
#include <exception>
#include<iostream>
#include<vector>
#include<map>
#include<set>
#include<list>
#include<vector>
#include<queue>
#include<algorithm>
#include <boost/thread/scoped_thread.hpp>


template <typename T> struct ThreadSafeQueue{
    ThreadSafeQueue() = default;
    ThreadSafeQueue(const ThreadSafeQueue& ) = delete; 
    ThreadSafeQueue& operator = (const ThreadSafeQueue& ) = delete;
    void push(T t){
        std::unique_lock<std::mutex> lk(m_m);
        m_q.push(t);
        m_cv.notify_one();
    }
    
    T pop(){
        std::unique_lock<std::mutex> lk(m_m);
        m_cv.wait(lk, [this]{return !m_q.empty(); } );
       T t = m_q.front();
        m_q.pop();    
        return t;
    }
   
   private:
       mutable std::mutex m_m;
       std::condition_variable m_cv;
       std::queue<T> m_q;
};

using Q = ThreadSafeQueue<int>;
Q q;
void th1()
{
    for(int i = 0; i < 100; ++i)
    {
       q.push(i);
       std::cout <<"push:"<< i<<  std::endl;
       std::this_thread::sleep_for(std::chrono::milliseconds(200));
    }
}


void th2()
{
    for(int i = 0; i < 100; ++i)
    {
      int val = q.pop();
       std::cout <<"pop:"<< val << std::endl;
      std::this_thread::sleep_for(std::chrono::milliseconds(100));
    }
}



int main(int, char*[])
{
    boost::scoped_thread<> g1( th1 );
     boost::scoped_thread<> g2( th2 );


    return 0;
}
