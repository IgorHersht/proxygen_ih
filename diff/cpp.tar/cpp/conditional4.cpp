
#include <thread>
#include <stack>
#include <mutex>
#include <memory>
#include <atomic>
#include <vector>
#include <deque>
#include <list>
#include <set>
#include <map>
#include <string>
#include <algorithm>
#include <iterator>
#include <functional>
#include <numeric>
#include <iostream>
#include <vector>
#include <list>
#include <deque>
#include <algorithm>
#include <typeinfo>
#include <algorithm>
#include <iterator>
#include <memory>
#include <stack>
#include <vector>
#include <condition_variable>

#include <boost/noncopyable.hpp>
#include <boost/thread/shared_mutex.hpp>

struct thread_guard{
  thread_guard(std::thread &t):m_t(t){
  }
  ~thread_guard(){
    if(m_t.joinable()) {
      m_t.join();
    }
  }
private:
  thread_guard& operator = (const thread_guard &) = delete;
  thread_guard(const thread_guard &) = delete;
  std::thread &m_t;

};

template <typename T> class sstack{
  sstack& operator = (const sstack &) = delete;
  sstack(const sstack &) = delete;
  typedef std::unique_lock<std::mutex> LockT;
public:
  sstack(){}
  void push(T &&v){
    LockT lk(m_mutex);
    m_stack.push(std::move(v) );
    m_not_empty.notify_one();
  }

 void pop(T &v){
    LockT lk(m_mutex);
    m_not_empty.wait(lk, [this] {return !m_stack.empty();});
    v = m_stack.top();
    m_stack.pop();

  }

private:

  std::mutex                        m_mutex;
  std::condition_variable           m_not_empty;
  std::stack<T>                     m_stack;

};

using SSS = sstack<std::string> ;


inline void push_all( SSS &s ){

  std::string st("YY");
  
  for (int i = 0; i < 10; ++i) {
   st += "xx";
   std::string out = st;
   s.push(std::move(out));
   //int j =1;
  }

}

inline void pop_all( SSS &s ){

  std::string st;
  
  for (int i = 0; i < 10; ++i) {
   s.pop(st);
   std::cout <<st<<std::endl;
  }

}



int main(){

    SSS st;
  std::thread t1(push_all, std::ref(st) );   thread_guard g1 (t1);
  std::thread t2(pop_all, std::ref(st));     thread_guard g2(t2);

	return 0;
}
