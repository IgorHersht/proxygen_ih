
#include <iostream>
#include <vector>
#include <queue>
#include <list>
#include <set>
#include <map>
#include <string>
#include <algorithm>
#include <iterator>
#include <functional>
#include <numeric>
#include <vector>
#include <memory>
#include <mutex>
#include <condition_variable>
#include <thread>


#ifndef _MAKE_UNIQUE_H
#define  _MAKE_UNIQUE_H

namespace tools
{

 template <class T, typename ...Args>  
 inline std::unique_ptr<T> make_unique(Args ...args)
{
    return std::unique_ptr<T>(new T(std::forward<Args>(args)...));
}
}
#endif
template <typename T> struct MQ{
    using Ptr  = std::unique_ptr<T> ;
 private:
   using CT = std::queue<Ptr>;
   using LT = std::unique_lock<std::mutex>;
   MQ(const MQ&) = delete;
   MQ operator = (const MQ&) = delete;
   public:
       MQ(){}
       void push(Ptr p){
           LT l(m_m);
           m_c.push(std::move(p));
           m_notEmpty.notify_one();
       }
       
       Ptr pop(){
            LT l(m_m);
            m_notEmpty.wait(l, [this](){return !m_c.empty(); });
            Ptr p = std::move( m_c.front());
            m_c.pop();
            return p;
       }
   private:
      CT                m_c;
      mutable std::mutex m_m;
      std::condition_variable m_notEmpty;
};

MQ<int> q;
void push()
{
   for(int i = 0; i <20; ++i){ 
       q.push(tools::make_unique<int>(i));
      std::cout <<"push:"<<i <<std::endl;
   }
}

void pop()
{
   for(int i = 0; i <20; ++i){ 
       std::unique_ptr<int> p = q.pop();
      std::cout <<"pop:"<<*p <<std::endl;
   }
}



int main(int, char*[])
{
    std::thread t1(pop);
    std::thread t2(push);
    t2.join();
    t1.join();
    return 0;
}
