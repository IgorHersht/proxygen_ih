/* The following code example is taken from the book
 * "C++ Templates - The Complete Guide"
 * by David Vandevoorde and Nicolai M. Josuttis, Addison-Wesley, 2002
 *
 * (C) Copyright David Vandevoorde and Nicolai M. Josuttis 2002.
 * Permission to copy, use, modify, sell and distribute this software
 * is granted provided this copyright notice appears in all copies.
 * This software is provided "as is" without express or implied
 * warranty, and with no claim as to its suitability for any purpose.
 */
#include <iostream>
template<bool C, typename T1, typename T2> struct IfThenElse;

template<typename T1, typename T2> struct IfThenElse<true, T1, T2> { typedef T1 ResultT ;};

template<typename T1, typename T2> struct IfThenElse<false, T1, T2> { typedef T2 ResultT ;};

template<typename T1, typename T2> struct Promotion {

	typedef typename IfThenElse< (sizeof(T1) > sizeof(T2) ), T1, T2> :: ResultT ResultT;
};


template<typename T1, typename T2> typename Promotion<T1, T2> :: ResultT add (T1 t1, T2 t2){
	Promotion<T1, T2> :: ResultT r = t1 + t2;
	return r;
}

int main()
{
	int r1 = add(3, (char)2 );
	int r2 = add( (char)3, 2.0 );
    
}
