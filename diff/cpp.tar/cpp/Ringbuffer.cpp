
#include <thread>
#include <mutex>
#include <vector>
#include <iostream>
#include <atomic>
/*
 * I assume resizable means grow if full
 * Push and pop with moveble data could be added 
 * Could be a little more efficient with dynamically allocated array ( don't need shrink_to_fit()); 
 */


template<typename T> struct  Ringbuffer {

  Ringbuffer(size_t size) : m_head(0), m_tail(0) {
	  m_ring.resize(size);
	  m_ring.shrink_to_fit();
  }

  void push(const T & value)
    {
     while(!tryPush(value)){
    	 std::vector<T> ring;
    	 ring.resize(m_ring.size() * 1.5);  //factor to 1.5 seems to be the best
    	 m_ring.shrink_to_fit();
    	 std::lock_guard<std::mutex> lk(m_m);
    	 m_ring.swap(ring);
     }
    }
  bool pop(T & value)
  {
	std::lock_guard<std::mutex> lk(m_m);
    size_t tail = m_tail.load(std::memory_order_relaxed);
    if (tail == m_head.load(std::memory_order_acquire))
      return false;
    value = m_ring[tail];
    m_tail.store(next(tail), std::memory_order_release);
    return true;
  }
private:
  bool tryPush(const T & value)
   {
     size_t head = m_head.load(std::memory_order_relaxed);
     size_t next_head = next(head);
     if (next_head == m_tail.load(std::memory_order_acquire))
       return false;
     m_ring[head] = value;
     m_head.store(next_head, std::memory_order_release);
     return true;
   }

private:
  size_t next(size_t current)
  {
    return (current + 1) % m_ring.size();
  }

  std::vector<T>      m_ring;// 
  std::atomic<size_t> m_head, m_tail;
  std::mutex          m_m;
};
// test

int main()
{
	Ringbuffer<int> r(3);
	r.push(1);
	r.push(1);
	r.push(1);
	r.push(1);

	int i = 0;
	bool s1 = r.pop(i);
	bool s2 = r.pop(i);
	bool s3 = r.pop(i);
	bool s4 = r.pop(i);

	return 0;
}

