
#include <future>
#include <thread>
#include <mutex>
#include <condition_variable>
#include <chrono>
#include <random>
#include <iostream>
#include <exception>
#include<iostream>
#include<vector>
#include<map>
#include<set>
#include<list>
#include<vector>
#include<queue>
#include<algorithm>


template <typename T>
struct ThreadSafeQueue
{
   ThreadSafeQueue(){}
    ThreadSafeQueue(const ThreadSafeQueue& ) = delete; 
   ThreadSafeQueue& operator = (const ThreadSafeQueue& ) = delete;
   
   void push (T val)
   {
       std::lock_guard<std::mutex> lk(m_m);
       m_data.push(val);
       m_cv.notify_one();
   }
   
   std::shared_ptr<T> pop()
   {
       std::unique_lock<std::mutex> lk(m_m);
       m_cv.wait(lk, [this]{return !m_data.empty(); });
       T val = m_data.front();
       m_data.pop();
       return std::make_shared<T>(val);
     
   }   
   
   private:
       mutable std::mutex m_m;
       std::condition_variable m_cv;
       std::queue<T>    m_data;    
    
};

ThreadSafeQueue<int> q;

void th1()
{
    for(int i = 0; i < 100; ++i)
    {
       q.push(i);
       std::cout <<"push:"<< i<<  std::endl;
       std::this_thread::sleep_for(std::chrono::milliseconds(200));
    }
}


void th2()
{
    for(int i = 0; i < 100; ++i)
    {
       std::shared_ptr<int> val = q.pop();
       std::cout <<"pop:"<< *val << std::endl;
      std::this_thread::sleep_for(std::chrono::milliseconds(100));
    }
}


int main(int argc, char* argv[])
{
    std::thread t1(th1);
    std::thread t2(th2);
    t1.join();
    t2.join();
 return 0;
}
 
