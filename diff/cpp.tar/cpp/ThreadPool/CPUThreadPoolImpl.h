/*
 * CPUThreadPoolWithContext.h
 *
 *  Created on: Jun 8, 2017
 *      Author: ihersht
 */

#pragma once
#include <wangle/concurrent/CPUThreadPoolExecutor.h>
namespace cpp_tools{

struct CPUThreadPoolImpl: public wangle::CPUThreadPoolExecutor{
		using wangle::CPUThreadPoolExecutor::CPUThreadPoolExecutor;

	 std::vector<std::thread::id> makeThreadIds(){
		const std::vector<wangle::CPUThreadPoolExecutor::ThreadPtr>& threads = threadList_.get();
		std::vector<std::thread::id> ids;
		for (size_t i= 0;  i <  threads.size(); ++i){
			if(UNLIKELY(!threads[i]) ){
				// error
				continue;
			}
			ids.push_back(threads[i]->handle. get_id());
		}
		return ids;
	}

	 template<  typename Ft, typename... Args > void submit( Ft &&func, Args&&... args){
		 wangle::CPUThreadPoolExecutor::add(std::forward<Ft>(func), std::forward<Args>(args)... );
	}

};



}
