/*
 * ThreadContextBase.h
 *
 *  Created on: Jun 12, 2017
 *      Author: ihersht
 */

#pragma once
#include "thread_pool_shared.h"
namespace cpp_tools{
	class ThreadContextBase{
		uint8_t m_padding[CacheLineSize]; //
	};

}
