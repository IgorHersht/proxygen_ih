/*
 * thread_pool_shared.h
 *
 *  Created on: Jun 7, 2017
 *      Author: ihersht
 */

#pragma once

#include<memory>
#include<map>
#include<thread>

#undef LIKELY
#undef UNLIKELY

#if defined(__GNUC__) && __GNUC__ >= 4
#define LIKELY(x)   (__builtin_expect((x), 1))
#define UNLIKELY(x) (__builtin_expect((x), 0))
#else
#define LIKELY(x)   (x)
#define UNLIKELY(x) (x)
#endif

namespace cpp_tools{
constexpr size_t CacheLineSize = 64;

using thread_id = std::thread::id;
template <typename ThreadContextT> using ThreadContextPtrT = std::unique_ptr<ThreadContextT>;
template <typename ThreadContextT> using ThreadsContextT = std::map<thread_id, ThreadContextPtrT<ThreadContextT> >;




}
