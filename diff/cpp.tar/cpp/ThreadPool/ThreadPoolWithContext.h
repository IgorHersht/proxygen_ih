/*
 * ThreadPoolWithContext.h
 *
 *  Created on: Jun 5, 2017
 *      Author: ihersht
 */

#pragma once
#include<memory>
#include<map>
#include<vector>

#include "thread_pool_shared.h"


namespace cpp_tools{

template <typename ThreadContextT, typename ImplT> class ThreadPoolWithContext :  public ImplT {
protected:
	 typedef ThreadContextPtrT<ThreadContextT> ThreadContextPtr;
	 typedef ThreadsContextT<ThreadContextT> ThreadsContext;
public:
	 ThreadsContext* getThreadsContext(){
		 return &m_ThreadsContext;
	 }

	 template< typename... Args >
		static std::vector<ThreadContextPtr > makeContexts(size_t contextNum, Args&&... args){
		std::vector<std::unique_ptr<ThreadContextT> >vec;
		for(size_t i =0; i < contextNum; ++i){
			auto con = std::make_unique<ThreadContextT>(std::forward<Args>(args)...);
			vec.push_back(std::move(con));
		}
		return vec;
	}

	template<  typename... Args >
	ThreadPoolWithContext(std::vector<ThreadContextPtr > contexts,  Args&&... args ): ImplT(contexts.size(),  std::forward<Args>(args)...){

		std::vector<std::thread::id> ids(this->makeThreadIds () );
		makeThreadsContext(std::move( contexts), std::move(ids ) );
	}


protected:
	void makeThreadsContext(std::vector<ThreadContextPtr > && contexts, std::vector<std::thread::id> &&ids){
		const size_t contextNum = contexts.size();
		const size_t idNum = ids.size();
		size_t iterNum = idNum;
		if(UNLIKELY(contextNum != idNum)){
			iterNum = std::min(contextNum, idNum );
			// error
		}
		for (size_t i= 0;  i <  iterNum; ++i){
			auto el = std::make_pair(ids[i], std::move(contexts[i] ));
			m_ThreadsContext.insert(std::move(el));
		}
	}
protected:
	ThreadsContext  m_ThreadsContext;
};





}
