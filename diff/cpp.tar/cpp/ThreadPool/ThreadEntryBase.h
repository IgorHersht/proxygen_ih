/*
 * ThreadEntry.h
 *
 *  Created on: Jun 6, 2017
 *      Author: ihersht
 */

#pragma once
#include "thread_pool_shared.h"
namespace cpp_tools{

template <typename ThreadContextT, typename Derived> struct ThreadEntryBase{
	typedef ThreadsContextT<ThreadContextT> ThreadsContext;

	explicit ThreadEntryBase( ThreadsContext *threadsContext): m_threadsContext(threadsContext){
	}
	/* TODO Try to use Curious template insted of virtual function
	 *
	 */

	void entry(ThreadContextT &threadContext){
		static_cast<Derived *>(this)->entry(threadContext);
	}

 void operator()(){
	if(UNLIKELY(!m_threadsContext)){
		//error
		return;
	}
	auto iter = m_threadsContext->find(std::this_thread::get_id());
	if(UNLIKELY(iter == m_threadsContext->end())){
		//error
		return;
	}
	ThreadContextT *threadContex = (iter->second).get();
	if(UNLIKELY(!threadContex)){
		//error
		return;
	}
	entry(*threadContex);

   }

private:
	ThreadsContext *m_threadsContext;
};

}



