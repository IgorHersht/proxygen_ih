template<typename T>
T checked (T a, T b)
{
    return  test() ? a : b;
}
