template<typename T> 
int f(T)
{ 
    return 1;
}

template<typename T> 
int f(T*)
{ 
    return 2;
}
