class override {};

class Base {
public:
  virtual ::override override(::override);  // override takes
                                            // and returns an
};                                          // ::override

class Derived: public Base {
public:
  ::override override(::override) override;  // an override
};                                            // of above :-)
