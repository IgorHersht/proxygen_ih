#ifndef ENCODING_MECHANISM02_H
#define ENCODING_MECHANISM02_H

template<typename T>
class Widget {
public:
  typedef T&& RvalueRefTot;
};

#endif /* ENCODING_MECHANISM02_H */
