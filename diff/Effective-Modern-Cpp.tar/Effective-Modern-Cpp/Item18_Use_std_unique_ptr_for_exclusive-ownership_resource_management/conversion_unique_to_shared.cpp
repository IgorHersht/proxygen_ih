// TODO
std::shared_ptr<Investment> sp =       // converts std::unique_ptr
  makeInvestment( /* arguments */ );   // to std::shared_ptr
