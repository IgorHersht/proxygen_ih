class Widget {
public:
  bool operator<(const Widget& other) const
  {
    return true;
  }
};
