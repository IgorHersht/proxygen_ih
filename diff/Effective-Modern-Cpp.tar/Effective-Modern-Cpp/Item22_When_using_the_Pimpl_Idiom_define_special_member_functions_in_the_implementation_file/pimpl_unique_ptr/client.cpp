#include "widget.h"

int main()
{
  Widget w;  // error
}
