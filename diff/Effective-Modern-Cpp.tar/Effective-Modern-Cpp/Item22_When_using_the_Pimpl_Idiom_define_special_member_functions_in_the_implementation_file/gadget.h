class Gadget {};
