/*
 * Key Idea:
 *
 *   Scoped enums can be forward-declared.
 */

//enum Color;         // error!
enum class Color;   // fine
