void myFunc1(int param[]) {}

void myFunc2(int* param) {}   // same function as above
