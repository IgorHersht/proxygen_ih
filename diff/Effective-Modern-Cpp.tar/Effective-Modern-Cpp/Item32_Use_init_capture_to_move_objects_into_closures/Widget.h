class Widget {  // some useful type
public:
  bool isValidated() const;
  bool isProcessed() const;
  bool isArchived() const;

private:

};
