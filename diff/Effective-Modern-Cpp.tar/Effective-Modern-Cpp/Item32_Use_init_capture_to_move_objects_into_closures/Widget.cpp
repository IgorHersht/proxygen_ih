#include "Widget.h"

bool Widget::isValidated() const { return true; }
bool Widget::isProcessed() const { return true; }
bool Widget::isArchived() const { return true; }
