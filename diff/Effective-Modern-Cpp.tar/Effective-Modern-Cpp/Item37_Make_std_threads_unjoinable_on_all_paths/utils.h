#include <iostream>
#include <vector>

bool conditionsAreSatisfied()
{
  //return true;
  return false;
}

void performComputation(std::vector<int>& goodVals)
{
  std::cout << "performComputation(std::vector<int>&)" << std::endl;
}

bool someFilter(int x)
{
  std::cout << "someFilter(int)" << std::endl;
}
