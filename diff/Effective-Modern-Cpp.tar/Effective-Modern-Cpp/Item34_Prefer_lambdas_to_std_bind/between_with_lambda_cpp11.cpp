auto betweenL =                               // C++11 version
  [lowVal, highVal]
  (int val)
  { return lowVal <= val && val <= highVal; };
