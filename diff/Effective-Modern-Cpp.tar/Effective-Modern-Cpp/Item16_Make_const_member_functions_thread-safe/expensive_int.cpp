#include "Widget1.h"
//#include "Widget2.h"
//#include "Widget3.h"

int main()
{
  Widget w;
  w.magicValue();
}
